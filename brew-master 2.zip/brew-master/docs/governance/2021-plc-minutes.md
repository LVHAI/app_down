# Homebrew Project Leadership Committee Minutes 2021

## Project Leader

[Mike McQuaid](https://github.com/mikemcquaid)

## PLC Members

- [Jon Chang](https://github.com/jonchang)
- [Markus Reiter](https://github.com/reitermarkus)
- [Misty De Méo](https://github.com/mistydemeo), secretary
- [Sean Molenaar](https://github.com/SMillerDev)
- [Issy Long](https://github.com/issyl0)

## Minutes

- 2021-03-10
  Misty De Méo proposed that the following members be appointed to the TSC for a one-year term: @mikemcquaid; @fxcoudert; @iMichka; @Bo98; @Rylan12.

  Motion carried unanimously.
