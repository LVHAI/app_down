# Extraordinary General Meeting 2021

## 2021-01-14

Meeting convened at 20:00 UTC.

Shaun Jackman moved to amend the governance document as per PR <https://github.com/Homebrew/brew/pull/10137>.

Votes in favour: 32
Votes opposed: 1
The motion carries.

Meeting adjourned at 20:07 UTC.
