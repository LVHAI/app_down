# Homebrew Project Leadership Committee Minutes 2019

## Members

- [Jon Chang](https://github.com/jonchang)
- [Markus Reiter](https://github.com/reitermarkus)
- [Mike McQuaid](https://github.com/mikemcquaid), project leader
- [Misty de Meo](https://github.com/mistydemeo)
- [Shaun Jackman](https://github.com/sjackman), secretary

## Minutes

- 2019-02-27
  Shaun Jackman moved that Torsten Seemann and Dominique Orban be invited to join Homebrew as members.

  Motion carried unanimously.
- 2019-07-19
  Shaun Jackman asked that Rui Chen be invited to join Homebrew as a member.

  Motion carried unanimously.
- 2019-08-24
  Jonathan Chang moved that Ladislas de Toldi and Zach Auten be invited to join Homebrew as members.

  Motion carried unanimously.
